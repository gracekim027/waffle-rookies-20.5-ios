//
//  LikedMovieState.swift
//  movies
//
//  Created by grace kim  on 2022/10/18.
//

import Foundation
import RxSwift
import UIKit

class LikedMovieState {
    //todo list 참고하기
    private var LikedMovies:[Movie] = []
    
    func addMovie(){
        
    }
    
    func removeMovie(){
        
    }
    
    func loadMovie(){
        
    }
    
}
